use D1;

select * from [dbo].[Sales_Data$];

select State,
       count(*) as TotalOrders,sum(Quantity) TotalQuantity, sum (NetSales) TotalSales, sum (Profit) as TotalProfit, AVG(NetSales) as AvgOrderValue
from [dbo].[Sales_Data$]
where OrderStatus='Completed' group by State
having sum(NetSales)>1000000 order by TotalSales desc;



--Q2--

with CustomerSales as(
select CustomerID,CustomerName,sum(NetSales) as TotalSales from [dbo].[Sales_Data$] where OrderStatus =  'Completed' group by CustomerID,CustomerName)
select top 5 CustomerID,CustomerName,TotalSales from CustomerSales order by TotalSales desc;


--Q3--

with StateSales as(
select State,
       sum(NetSales) as TotalSales from [dbo].[Sales_Data$] where OrderStatus = 'Completed' group by State)
select State, TotalSales, RANK() over (order by TotalSales desc) as SalesRank from StateSales order by SalesRank;
      

       
       


